alpha_Gins=logspace(0,log10(16),16);
alpha_Gress= logspace(log10(0.125),log10(4),16);
err=zeros(length(alpha_Gins),length(alpha_Gress));
spikingactivity=zeros(length(alpha_Gins),length(alpha_Gress));
ipspikingactivity=zeros(length(alpha_Gins),length(alpha_Gress));

parfor i = 1:length(alpha_Gins)
er=zeros(1,length(alpha_Gress));
spikingactivit=zeros(1,length(alpha_Gress));
ipspikingactivit=zeros(1,length(alpha_Gress));
    for j = 1:length(alpha_Gress)
        [er(j),spikingactivit(j),ipspikingactivit(j)]=stage1(alpha_Gins(i),alpha_Gress(j));
        j
    end
    err(i,:)=er
    spikingactivity(i,:)=spikingactivit;
    ipspikingactivity(i,:)=ipspikingactivit;
end

figure(1)
a=pcolor(log10(alpha_Gins),log10(alpha_Gress),log(err'))
xticks([0,log10(2),log10(4),log10(8),log10(16)])
xticklabels([1,2,4,8,16])
yticks([log10(0.25),log10(0.5),log10(1),log10(2),log10(4)])
yticklabels([0.25,0.5,1,2,4])
a.FaceColor = 'interp';
title('Error')
xlabel('alpha_{Gins}'); ylabel('alpha_{Gres}')
figure(2)
a2=pcolor(log10(alpha_Gins),log10(alpha_Gress),log10(spikingactivity'))
xticks([0,log10(2),log10(4),log10(8),log10(16)])
xticklabels([1,2,4,8,16])
yticks([log10(0.25),log10(0.5),log10(1),log10(2),log10(4)])
yticklabels([0.25,0.5,1,2,4])
a2.FaceColor = 'interp';
title('Spiking Activity')
xlabel('alpha_{Gins}'); ylabel('alpha_{Gres}')
figure(3)
scatter(log10(spikingactivity),log10( err))
xticks([2,3,4,5])
xticklabels([10^2,10^3,10^4,10^5])
yticks([log10(2),log10(5),log10(10),log10(20),log10(50),log10(100)])
yticklabels([2,5,10,20,50,100])
xlabel('Spiking Activity'); ylabel('Error')
